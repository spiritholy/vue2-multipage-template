module.exports = ['page1', 'page2'];
