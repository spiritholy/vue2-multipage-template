<style lang="css">
</style>

<template lang="html">
  <div>
    <div>{{name}}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: 'Tom',
    }
  },
}
</script>
