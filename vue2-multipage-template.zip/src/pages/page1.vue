<style lang="css">
.page1 {
  color: #f00;
  background-image: url('./../assets/Desert.jpg');
}
</style>

<template lang="html">
  <div>
    <div class="page1">this is page1</div>
    <img :src="img" alt="">
  </div>
</template>

<script>

import desert from '../assets/Desert.jpg'

export default {
  name: 'page1',
  data() {
    return {
      img: desert,
    }
  },
}
</script>
