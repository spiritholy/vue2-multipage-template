<style lang="css">
.page2 {
  color: #0f0;
}
</style>

<template lang="html">
  <div class="page2">this is page2</div>
</template>

<script>
export default {
  name: 'page2',
}
</script>
