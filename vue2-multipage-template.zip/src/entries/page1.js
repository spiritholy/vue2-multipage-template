import 'bootstrap/dist/css/bootstrap.css'
import createVue from '../main'

import page1 from '../pages/page1'

createVue(page1)
