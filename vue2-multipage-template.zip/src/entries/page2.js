import 'bootstrap/dist/css/bootstrap.css'
import createVue from '../main'

import page2 from '../pages/page2'

createVue(page2)
